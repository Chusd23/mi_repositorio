use minimercado;
CREATE TABLE categoria (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT
);

CREATE TABLE proveedor (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  telefono VARCHAR(20),
  email VARCHAR(100)
);

CREATE TABLE producto (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  descripcion TEXT,
  precio DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL,
  categoria_id INT,
  proveedor_id INT,
  FOREIGN KEY (categoria_id) REFERENCES categoria(id),
  FOREIGN KEY (proveedor_id) REFERENCES proveedor(id)
);

CREATE TABLE usuario (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150),
  documento VARCHAR(50),
  telefono VARCHAR(30),
  email VARCHAR(100),
  tipo ENUM('CLIENTE','EMPLEADO') NOT NULL
);

CREATE TABLE venta (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
  empleado_id INT,
  cliente_id INT,
  total DECIMAL(10,2),
  pago_id INT,
  FOREIGN KEY (empleado_id) REFERENCES usuario(id),
  FOREIGN KEY (cliente_id) REFERENCES usuario(id)
);

CREATE TABLE detalle_venta (
  id INT AUTO_INCREMENT PRIMARY KEY,
  venta_id INT,
  producto_id INT,
  cantidad INT,
  precio_unitario DECIMAL(10,2),
  subtotal DECIMAL(10,2),
  FOREIGN KEY (venta_id) REFERENCES venta(id),
  FOREIGN KEY (producto_id) REFERENCES producto(id)
);

CREATE TABLE pago (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipo ENUM('EFECTIVO','TARJETA','TRANSFERENCIA') NOT NULL,
  monto DECIMAL(10,2),
  referencia VARCHAR(255) -- por ejemplo, n° de transacción o nro tarjeta enmascarado
);

show columns from usuario;



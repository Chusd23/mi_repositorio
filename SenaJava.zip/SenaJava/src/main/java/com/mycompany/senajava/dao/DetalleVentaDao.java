/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.senajava.dao;

import com.mycompany.senajava.minimercado.modelo.DetalleVenta;
import java.sql.*;
import java.util.*;

public class DetalleVentaDao {
    private Connection con;

    public DetalleVentaDao(Connection con) {
        this.con = con;
    }

    public void insertar(DetalleVenta d) throws SQLException {
        String sql = "INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, d.getVentaId());
            ps.setInt(2, d.getProductoId());
            ps.setInt(3, d.getCantidad());
            ps.setDouble(4, d.getPrecioUnitario());
            ps.setDouble(5, d.getSubtotal());
            ps.executeUpdate();
        }
    }

    public List<DetalleVenta> listar() throws SQLException {
        List<DetalleVenta> lista = new ArrayList<>();
        String sql = "SELECT * FROM detalle_venta";
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new DetalleVenta(
                    rs.getInt("id"),
                    rs.getInt("venta_id"),
                    rs.getInt("producto_id"),
                    rs.getInt("cantidad"),
                    rs.getDouble("precio_unitario"),
                    rs.getDouble("subtotal")
                ));
            }
        }
        return lista;
    }
}

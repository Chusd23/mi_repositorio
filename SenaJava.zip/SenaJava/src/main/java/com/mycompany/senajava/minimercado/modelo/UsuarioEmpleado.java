/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.senajava.minimercado.modelo;

public class UsuarioEmpleado extends Usuario {

    public UsuarioEmpleado() {
        super();
        this.tipo = "EMPLEADO";
    }

    public UsuarioEmpleado(int id, String nombre, String documento, String telefono, String email) {
        super(id, nombre, documento, telefono, email, "EMPLEADO");
    }
}

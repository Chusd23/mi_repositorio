/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.senajava.dao;

import com.mycompany.senajava.minimercado.modelo.*;
import java.sql.*;
import java.util.*;

public class UsuarioDao {

    private Connection con;

    public UsuarioDao(Connection con) {
        this.con = con;
    }

    // ✅ INSERTAR
    public void insertar(Usuario u) throws SQLException {
        String sql = "INSERT INTO usuario (nombre, documento, telefono, email, tipo) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, u.getNombre());
            ps.setString(2, u.getDocumento());
            ps.setString(3, u.getTelefono());
            ps.setString(4, u.getEmail());
            ps.setString(5, u.getTipo());
            ps.executeUpdate();
        }
    }

    // ✅ ACTUALIZAR
    public void actualizar(Usuario u) throws SQLException {
        String sql = "UPDATE usuario SET nombre=?, documento=?, telefono=?, email=?, tipo=? WHERE id=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, u.getNombre());
            ps.setString(2, u.getDocumento());
            ps.setString(3, u.getTelefono());
            ps.setString(4, u.getEmail());
            ps.setString(5, u.getTipo());
            ps.setInt(6, u.getId());
            ps.executeUpdate();
        }
    }

    // ✅ ELIMINAR
    public void eliminar(int id) throws SQLException {
        String sql = "DELETE FROM usuario WHERE id=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    // ✅ LISTAR TODOS
    public List<Usuario> listar() throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuario";
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Usuario u;
                String tipo = rs.getString("tipo");
                if ("CLIENTE".equalsIgnoreCase(tipo)) {
                    u = new UsuarioCliente(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("documento"),
                        rs.getString("telefono"),
                        rs.getString("email")
                    );
                } else {
                    u = new UsuarioEmpleado(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("documento"),
                        rs.getString("telefono"),
                        rs.getString("email")
                    );
                }
                lista.add(u);
            }
        }
        return lista;
    }

    // ✅ BUSCAR POR ID
    public Usuario buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM usuario WHERE id=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String tipo = rs.getString("tipo");
                    if ("CLIENTE".equalsIgnoreCase(tipo)) {
                        return new UsuarioCliente(
                            rs.getInt("id"),
                            rs.getString("nombre"),
                            rs.getString("documento"),
                            rs.getString("telefono"),
                            rs.getString("email")
                        );
                    } else {
                        return new UsuarioEmpleado(
                            rs.getInt("id"),
                            rs.getString("nombre"),
                            rs.getString("documento"),
                            rs.getString("telefono"),
                            rs.getString("email")
                        );
                    }
                }
            }
        }
        return null;
    }
}



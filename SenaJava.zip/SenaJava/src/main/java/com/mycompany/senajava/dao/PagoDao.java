/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.senajava.dao;

import com.mycompany.senajava.minimercado.modelo.Pago;
import java.sql.*;
import java.util.*;

public class PagoDao {
    private Connection con;

    public PagoDao(Connection con) {
        this.con = con;
    }

    public void insertar(Pago p) throws SQLException {
        String sql = "INSERT INTO pago (tipo, monto, referencia) VALUES (?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getTipo());
            ps.setDouble(2, p.getMonto());
            ps.setString(3, p.getReferencia());
            ps.executeUpdate();
        }
    }

    public List<Pago> listar() throws SQLException {
        List<Pago> lista = new ArrayList<>();
        String sql = "SELECT * FROM pago";
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Pago(
                    rs.getInt("id"),
                    rs.getString("tipo"),
                    rs.getDouble("monto"),
                    rs.getString("referencia")
                ));
            }
        }
        return lista;
    }
}


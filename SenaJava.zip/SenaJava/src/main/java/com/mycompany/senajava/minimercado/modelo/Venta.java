/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.senajava.minimercado.modelo;

/**
 *
 * @author VICTUS
 */
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Venta {
    private int id;
    private LocalDateTime fecha;
    private Integer empleadoId;
    private Integer clienteId;
    private double total;
    private Integer pagoId;
    private List<DetalleVenta> detalles = new ArrayList<>();

    public Venta() {}

    public Venta(Integer empleadoId, Integer clienteId, double total, Integer pagoId) {
        this.fecha = LocalDateTime.now();
        this.empleadoId = empleadoId;
        this.clienteId = clienteId;
        this.total = total;
        this.pagoId = pagoId;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }

    public Integer getEmpleadoId() { return empleadoId; }
    public void setEmpleadoId(Integer empleadoId) { this.empleadoId = empleadoId; }

    public Integer getClienteId() { return clienteId; }
    public void setClienteId(Integer clienteId) { this.clienteId = clienteId; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public Integer getPagoId() { return pagoId; }
    public void setPagoId(Integer pagoId) { this.pagoId = pagoId; }

    public List<DetalleVenta> getDetalles() { return detalles; }
    public void setDetalles(List<DetalleVenta> detalles) { this.detalles = detalles; }

    public void agregarDetalle(DetalleVenta detalle) {
        detalles.add(detalle);
    }

    @Override
    public String toString() {
        return "Venta{" +
                "id=" + id +
                ", fecha=" + fecha +
                ", empleadoId=" + empleadoId +
                ", clienteId=" + clienteId +
                ", total=" + total +
                ", pagoId=" + pagoId +
                ", detalles=" + detalles +
                '}';
    }
}

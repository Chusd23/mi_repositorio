/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.senajava.minimercado.modelo;

/**
 *
 * @author VICTUS
 */
public class Pago {
    private int id;
    private String tipo; // EFECTIVO, TARJETA, TRANSFERENCIA
    private double monto;
    private String referencia;

    public Pago() {}

    public Pago(int id,String tipo, double monto, String referencia) {
        this.id=id;
        this.tipo = tipo;
        this.monto = monto;
        this.referencia = referencia;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public double getMonto() { return monto; }
    public void setMonto(double monto) { this.monto = monto; }

    public String getReferencia() { return referencia; }
    public void setReferencia(String referencia) { this.referencia = referencia; }

    @Override
    public String toString() {
        return "Pago{" +
                "id=" + id +
                ", tipo='" + tipo + '\'' +
                ", monto=" + monto +
                ", referencia='" + referencia + '\'' +
                '}';
    }
}

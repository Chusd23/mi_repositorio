/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.senajava.minimercado.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    // Cambia los valores según tu configuración
    private static final String URL = "jdbc:mysql://localhost:3306/minimercado";
    private static final String USUARIO = "root";
    private static final String CLAVE = "1064837999";
    private static Connection conexion = null;

    // 🔹 Obtener conexión (singleton)
    public static Connection getConexion() {
        try {
            if (conexion == null || conexion.isClosed()) {
                // Registrar el driver
                Class.forName("com.mysql.cj.jdbc.Driver");
                conexion = DriverManager.getConnection(URL, USUARIO, CLAVE);
                System.out.println("✅ Conexión establecida con la base de datos");
            }
        } catch (ClassNotFoundException e) {
            System.err.println("❌ No se encontró el driver de MySQL: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("❌ Error al conectar con la base de datos: " + e.getMessage());
        }
        return conexion;
    }

    // 🔹 Cerrar conexión manualmente (opcional)
    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("🔒 Conexión cerrada correctamente");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al cerrar la conexión: " + e.getMessage());
        }
    }
}

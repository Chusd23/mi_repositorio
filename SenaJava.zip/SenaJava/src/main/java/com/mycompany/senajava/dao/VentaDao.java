/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.senajava.minimercado.dao;

import com.mycompany.senajava.minimercado.modelo.Venta;
import com.mycompany.senajava.minimercado.utils.Conexion;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class VentaDao {

    // 🔹 Crear una nueva venta
    public boolean insertar(Venta venta) {
        String sql = "INSERT INTO venta (fecha, empleado_id, cliente_id, total, pago_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setTimestamp(1, Timestamp.valueOf(venta.getFecha()));
            ps.setObject(2, venta.getEmpleadoId(), Types.INTEGER);
            ps.setObject(3, venta.getClienteId(), Types.INTEGER);
            ps.setDouble(4, venta.getTotal());
            ps.setObject(5, venta.getPagoId(), Types.INTEGER);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                // Obtener el ID generado
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        venta.setId(rs.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar venta: " + e.getMessage());
        }
        return false;
    }

    // 🔹 Obtener una venta por su ID
    public Venta obtenerPorId(int id) {
        String sql = "SELECT * FROM venta WHERE id = ?";
        Venta venta = null;

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                venta = new Venta();
                venta.setId(rs.getInt("id"));
                venta.setFecha(rs.getTimestamp("fecha").toLocalDateTime());
                venta.setEmpleadoId((Integer) rs.getObject("empleado_id"));
                venta.setClienteId((Integer) rs.getObject("cliente_id"));
                venta.setTotal(rs.getDouble("total"));
                venta.setPagoId((Integer) rs.getObject("pago_id"));
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener venta: " + e.getMessage());
        }
        return venta;
    }

    // 🔹 Listar todas las ventas
    public List<Venta> listarTodas() {
        List<Venta> lista = new ArrayList<>();
        String sql = "SELECT * FROM venta";

        try (Connection con = Conexion.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Venta venta = new Venta();
                venta.setId(rs.getInt("id"));
                venta.setFecha(rs.getTimestamp("fecha").toLocalDateTime());
                venta.setEmpleadoId((Integer) rs.getObject("empleado_id"));
                venta.setClienteId((Integer) rs.getObject("cliente_id"));
                venta.setTotal(rs.getDouble("total"));
                venta.setPagoId((Integer) rs.getObject("pago_id"));
                lista.add(venta);
            }

        } catch (SQLException e) {
            System.err.println("Error al listar ventas: " + e.getMessage());
        }
        return lista;
    }

    // 🔹 Actualizar una venta existente
    public boolean actualizar(Venta venta) {
        String sql = "UPDATE venta SET fecha=?, empleado_id=?, cliente_id=?, total=?, pago_id=? WHERE id=?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setTimestamp(1, Timestamp.valueOf(venta.getFecha()));
            ps.setObject(2, venta.getEmpleadoId(), Types.INTEGER);
            ps.setObject(3, venta.getClienteId(), Types.INTEGER);
            ps.setDouble(4, venta.getTotal());
            ps.setObject(5, venta.getPagoId(), Types.INTEGER);
            ps.setInt(6, venta.getId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar venta: " + e.getMessage());
        }
        return false;
    }

    // 🔹 Eliminar una venta
    public boolean eliminar(int id) {
        String sql = "DELETE FROM venta WHERE id=?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar venta: " + e.getMessage());
        }
        return false;
    }
}



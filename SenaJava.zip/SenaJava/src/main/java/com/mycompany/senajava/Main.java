/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.senajava;

import com.mycompany.senajava.minimercado.modelo.Producto;
import com.mycompany.senajava.dao.ProductoDao;

public class Main {
    public static void main(String[] args) {

        ProductoDao productoDAO = new ProductoDao();

        // Crear productos de tienda
        Producto producto1 = new Producto(0, "Arroz Diana 1kg", "Arroz blanco tradicional", 3800.0, 50, 1, 1);
        Producto producto2 = new Producto(0, "Aceite Premier 1L", "Aceite vegetal comestible", 10500.0, 30, 1, 2);

        // Insertar productos
        boolean exito1 = productoDAO.insertar(producto1);
        boolean exito2 = productoDAO.insertar(producto2);

        // Mostrar resultado
        if (exito1 && exito2) {
            System.out.println("✅ Productos insertados correctamente en la base de datos.");
        } else {
            System.out.println("❌ Ocurrió un error al insertar los productos.");
        }
    }
}

